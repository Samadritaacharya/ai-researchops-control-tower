"""Data loading helpers for the AI ResearchOps Control Tower.

Every CSV lives in the ``data/`` folder at the project root. These helpers
resolve that path relative to this file (so the app works no matter what the
current working directory is) and fall back to a small in-memory sample if a
file is missing, so the dashboard never crashes on a fresh checkout.
"""

import os

import pandas as pd

# data/ sits next to the utils/ package, one level up from this file.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")


def _read_csv(filename, fallback):
    """Read a CSV from the data directory, returning a fallback on any error.

    Args:
        filename: name of the file inside ``data/``.
        fallback: a DataFrame to return if the file is missing or unreadable.

    Returns:
        pandas.DataFrame
    """
    path = os.path.join(DATA_DIR, filename)
    try:
        return pd.read_csv(path)
    except Exception:  # noqa: BLE001 - any read failure should degrade gracefully
        return fallback.copy()


def load_project_data():
    """Load the research projects table."""
    fallback = pd.DataFrame(
        {
            "project_id": ["P001"],
            "project_name": ["Sample Project"],
            "research_goal": ["Demonstrate the dashboard"],
            "primary_researcher": ["Demo User"],
            "start_date": ["2024-01-01"],
            "expected_end_date": ["2024-12-31"],
            "status": ["Active"],
            "goal_volatility": [5],
            "data_uncertainty": [5],
            "model_uncertainty": [5],
            "stakeholder_dependency": [5],
            "legal_complexity": [5],
        }
    )
    return _read_csv("sample_research_projects.csv", fallback)


def load_risks():
    """Load the risk register table."""
    fallback = pd.DataFrame(
        {
            "risk_id": ["R001"],
            "project_id": ["P001"],
            "title": ["Sample risk"],
            "category": ["Model Risks"],
            "description": ["Placeholder risk"],
            "impact": [3],
            "likelihood": [3],
            "mitigation": ["Monitor"],
            "owner": ["Demo User"],
            "status": ["Open"],
        }
    )
    return _read_csv("risk_register.csv", fallback)


def load_tasks():
    """Load the task backlog table."""
    fallback = pd.DataFrame(
        {
            "task_id": ["T001"],
            "project_id": ["P001"],
            "task_name": ["Sample task"],
            "owner": ["Demo User"],
            "status": ["In Progress"],
            "clear_objective": ["Yes"],
            "has_owner": ["Yes"],
            "has_output": ["Yes"],
            "acceptance_criteria": ["Yes"],
            "dependencies": ["None"],
            "ai_metric": ["Accuracy"],
            "risk_level": ["Medium"],
            "timeline": ["2024-12-31"],
            "stakeholder_impact": ["Medium"],
        }
    )
    return _read_csv("task_backlog.csv", fallback)


def load_stakeholders():
    """Load the stakeholder / RACI table."""
    fallback = pd.DataFrame(
        {
            "project_id": ["P001"],
            "stakeholder_name": ["Demo User"],
            "role": ["Researcher"],
            "responsible": ["Yes"],
            "accountable": ["No"],
            "consulted": ["No"],
            "informed": ["No"],
        }
    )
    return _read_csv("stakeholder_map.csv", fallback)


def load_experiments():
    """Load the experiment tracker table."""
    fallback = pd.DataFrame(
        {
            "experiment_id": ["EXP001"],
            "project_id": ["P001"],
            "track": ["Intent Detection"],
            "experiment_name": ["Sample experiment"],
            "hypothesis": ["Placeholder hypothesis"],
            "baseline_metric": ["50%"],
            "target_metric": ["70%"],
            "actual_metric": ["60%"],
            "dataset_size": ["1000 samples"],
            "status": ["Completed"],
            "start_date": ["2024-01-01"],
            "end_date": ["2024-02-01"],
        }
    )
    return _read_csv("experiment_tracker.csv", fallback)


def metric_to_float(value):
    """Convert a metric string such as ``"68%"`` to a float (68.0).

    Returns ``None`` for blanks / unparseable values so callers can skip them.
    """
    if value is None:
        return None
    text = str(value).strip().replace("%", "")
    if text == "" or text.lower() == "nan":
        return None
    try:
        return float(text)
    except ValueError:
        return None
