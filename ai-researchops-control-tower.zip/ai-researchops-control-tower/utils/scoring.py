"""Scoring functions for the AI ResearchOps Control Tower.

This module centralises every numeric score used across the app so the logic
lives in exactly one place and can be unit-tested in isolation. All functions
are intentionally simple and side-effect free.
"""

# ---------------------------------------------------------------------------
# Score thresholds (single source of truth for the whole app)
# ---------------------------------------------------------------------------
HIGH_RISK_THRESHOLD = 15          # risk score above which a risk is "high"
HANDOVER_READY_THRESHOLD = 80     # readiness score above which a project can hand over
TASK_GREEN_THRESHOLD = 80         # task completeness >= this is "green"
TASK_YELLOW_THRESHOLD = 50        # task completeness >= this is "yellow", else "red"

# The nine fields that make a task "complete" (used by the analyzer page too)
TASK_REQUIRED_FIELDS = [
    "clear_objective",
    "has_owner",
    "has_output",
    "acceptance_criteria",
    "dependencies",
    "ai_metric",
    "risk_level",
    "timeline",
    "stakeholder_impact",
]


def calculate_uncertainty_score(
    goal_volatility,
    data_uncertainty,
    model_uncertainty,
    stakeholder_dependency,
    legal_complexity,
):
    """Return the average uncertainty score for a project.

    Range: 1-10 (the mean of five 1-10 inputs).

    Args:
        goal_volatility: 1-10, how much the goals might change.
        data_uncertainty: 1-10, data availability / quality risk.
        model_uncertainty: 1-10, model performance / generalization risk.
        stakeholder_dependency: 1-10, number / alignment of stakeholders.
        legal_complexity: 1-10, privacy / compliance requirements.

    Returns:
        float: mean of the five components.
    """
    return (
        goal_volatility
        + data_uncertainty
        + model_uncertainty
        + stakeholder_dependency
        + legal_complexity
    ) / 5


# Values that mean "this field was not meaningfully filled in".
_EMPTY_VALUES = {"", "no", "none", "nan", "tbd", "n/a", "na"}


def calculate_task_completeness(task_dict):
    """Return how complete a task is as a 0-100 percentage.

    This is a *presence* check, matching the field's intent: a field counts as
    complete when it has a meaningful value. That covers two cases in the data:

    * Yes/No fields (e.g. ``clear_objective``) — ``"Yes"`` counts, ``"No"`` does
      not.
    * Content fields (e.g. ``ai_metric`` = ``"F1 score"``, ``timeline`` = a
      date) — any real value counts.

    A field is treated as *not* filled when it is missing or equal to one of the
    empty sentinels ("", "No", "None", "TBD", "N/A", NaN).

    Args:
        task_dict: mapping of field name -> value.

    Returns:
        float: percentage of the nine required fields that are filled.
    """
    completed = 0
    for field in TASK_REQUIRED_FIELDS:
        value = task_dict.get(field)
        if value is None:
            continue
        if str(value).strip().lower() not in _EMPTY_VALUES:
            completed += 1
    return (completed / len(TASK_REQUIRED_FIELDS)) * 100


def calculate_handover_readiness(
    evaluation_quality,
    reproducibility,
    stakeholder_alignment,
    risk_closure,
    documentation_maturity,
):
    """Return the product handover readiness score on a 0-100 scale.

    Each component is scored 1-10. The mean of the five components is scaled by
    10 so a perfect 10/10 across the board maps to 100.

    Returns:
        float: readiness score in the range 0-100.
    """
    return (
        evaluation_quality
        + reproducibility
        + stakeholder_alignment
        + risk_closure
        + documentation_maturity
    ) / 5 * 10


def calculate_risk_score(impact, likelihood):
    """Return the risk score (impact x likelihood).

    Args:
        impact: 1-5.
        likelihood: 1-5.

    Returns:
        int/float: risk score in the range 1-25.
    """
    return impact * likelihood


# ---------------------------------------------------------------------------
# Convenience classifiers built on top of the raw scores
# ---------------------------------------------------------------------------
def uncertainty_zone(score):
    """Bucket an uncertainty score (1-10) into Low / Medium / High."""
    if score < 4:
        return "Low"
    if score < 7:
        return "Medium"
    return "High"


def task_completeness_color(percentage):
    """Map a completeness percentage to a traffic-light label."""
    if percentage >= TASK_GREEN_THRESHOLD:
        return "Green"
    if percentage >= TASK_YELLOW_THRESHOLD:
        return "Yellow"
    return "Red"


def is_high_risk(risk_score):
    """True when a risk score is above the high-risk threshold."""
    return risk_score > HIGH_RISK_THRESHOLD


def is_handover_ready(readiness_score):
    """True when a readiness score clears the handover threshold."""
    return readiness_score > HANDOVER_READY_THRESHOLD
