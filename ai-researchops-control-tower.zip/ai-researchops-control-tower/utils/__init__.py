"""Utility package for the AI ResearchOps Control Tower.

Exposes scoring, data loading, and visualization helpers used across the app.
"""
