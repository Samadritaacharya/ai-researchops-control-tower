"""Reusable Plotly chart builders for the AI ResearchOps Control Tower.

Each function returns a ``plotly.graph_objects.Figure`` so pages can simply do
``st.plotly_chart(fig, use_container_width=True)``. Keeping the chart logic here
means the brand palette is applied consistently everywhere.
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from utils.data_loader import metric_to_float
from utils.scoring import calculate_uncertainty_score, calculate_risk_score

# Brand palette (shared with the Streamlit theme / CSS)
PRIMARY = "#0B5B73"   # Teal
SECONDARY = "#1F3347"  # Navy
SUCCESS = "#2ECC71"   # Green
WARNING = "#F39C12"   # Orange
DANGER = "#E74C3C"    # Red

STATUS_COLORS = {
    "Active": PRIMARY,
    "Completed": SUCCESS,
    "Draft": WARNING,
    "On Hold": SECONDARY,
}


def _base_layout(fig, title=None):
    """Apply consistent styling to every figure."""
    fig.update_layout(
        title=title,
        font=dict(family="Calibri, Segoe UI, sans-serif", color=SECONDARY),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=20, t=50, b=40),
    )
    return fig


def project_status_pie(projects):
    """Donut chart of project counts by status."""
    counts = projects["status"].value_counts().reset_index()
    counts.columns = ["status", "count"]
    fig = px.pie(
        counts,
        names="status",
        values="count",
        hole=0.5,
        color="status",
        color_discrete_map=STATUS_COLORS,
    )
    fig.update_traces(textposition="inside", textinfo="label+value")
    return _base_layout(fig, "Project Status Distribution")


def uncertainty_distribution(projects):
    """Histogram of per-project uncertainty scores."""
    scores = projects.apply(
        lambda r: calculate_uncertainty_score(
            r["goal_volatility"],
            r["data_uncertainty"],
            r["model_uncertainty"],
            r["stakeholder_dependency"],
            r["legal_complexity"],
        ),
        axis=1,
    )
    fig = px.histogram(
        x=scores,
        nbins=10,
        range_x=[0, 10],
        color_discrete_sequence=[PRIMARY],
    )
    fig.update_layout(xaxis_title="Uncertainty Score (1-10)", yaxis_title="Projects")
    return _base_layout(fig, "Uncertainty Score Distribution")


def risk_heatmap(risks):
    """Heatmap of risk counts across the impact x likelihood grid (1-5)."""
    # Build a 5x5 grid of counts.
    grid = [[0 for _ in range(5)] for _ in range(5)]
    for _, row in risks.iterrows():
        try:
            impact = int(row["impact"])
            likelihood = int(row["likelihood"])
        except (ValueError, TypeError):
            continue
        if 1 <= impact <= 5 and 1 <= likelihood <= 5:
            grid[impact - 1][likelihood - 1] += 1

    fig = go.Figure(
        data=go.Heatmap(
            z=grid,
            x=[f"L{i}" for i in range(1, 6)],
            y=[f"I{i}" for i in range(1, 6)],
            colorscale=[[0, "#EAF2F4"], [0.5, PRIMARY], [1, DANGER]],
            showscale=True,
            text=grid,
            texttemplate="%{text}",
            hovertemplate="Impact %{y}, Likelihood %{x}: %{z} risks<extra></extra>",
        )
    )
    fig.update_layout(xaxis_title="Likelihood", yaxis_title="Impact")
    return _base_layout(fig, "Risk Heatmap (count by Impact x Likelihood)")


def uncertainty_bubble_matrix(projects):
    """2D bubble matrix: goal volatility vs data/model uncertainty.

    Bubble size encodes stakeholder dependency. The combined data/model axis is
    the mean of data and model uncertainty.
    """
    df = projects.copy()
    df["data_model_uncertainty"] = (
        df["data_uncertainty"] + df["model_uncertainty"]
    ) / 2
    df["uncertainty_score"] = df.apply(
        lambda r: calculate_uncertainty_score(
            r["goal_volatility"],
            r["data_uncertainty"],
            r["model_uncertainty"],
            r["stakeholder_dependency"],
            r["legal_complexity"],
        ),
        axis=1,
    )
    fig = px.scatter(
        df,
        x="goal_volatility",
        y="data_model_uncertainty",
        size="stakeholder_dependency",
        color="uncertainty_score",
        hover_name="project_name",
        text="project_id",
        size_max=45,
        range_x=[0, 10],
        range_y=[0, 10],
        color_continuous_scale=[[0, SUCCESS], [0.5, WARNING], [1, DANGER]],
    )
    fig.update_traces(textposition="top center")
    fig.update_layout(
        xaxis_title="Goal Volatility (1-10)",
        yaxis_title="Data / Model Uncertainty (1-10)",
    )
    return _base_layout(fig, "Uncertainty & Scope Matrix")


def experiment_trend(experiments):
    """Line chart comparing baseline vs actual metrics per experiment."""
    df = experiments.copy()
    df["baseline_val"] = df["baseline_metric"].apply(metric_to_float)
    df["actual_val"] = df["actual_metric"].apply(metric_to_float)
    df = df.sort_values("start_date")

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=df["experiment_name"],
            y=df["baseline_val"],
            mode="lines+markers",
            name="Baseline",
            line=dict(color=SECONDARY, dash="dot"),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=df["experiment_name"],
            y=df["actual_val"],
            mode="lines+markers",
            name="Actual",
            line=dict(color=PRIMARY),
        )
    )
    fig.update_layout(xaxis_title="Experiment", yaxis_title="Metric value")
    return _base_layout(fig, "Baseline vs Actual Metrics")


def stakeholder_involvement_heatmap(stakeholders):
    """Heatmap of RACI involvement counts by role."""
    raci_cols = ["responsible", "accountable", "consulted", "informed"]
    df = stakeholders.copy()
    rows = []
    for role, group in df.groupby("role"):
        counts = [(group[col] == "Yes").sum() for col in raci_cols]
        rows.append(counts)
    roles = list(df.groupby("role").groups.keys())

    fig = go.Figure(
        data=go.Heatmap(
            z=rows,
            x=["Responsible", "Accountable", "Consulted", "Informed"],
            y=roles,
            colorscale=[[0, "#EAF2F4"], [1, PRIMARY]],
            text=rows,
            texttemplate="%{text}",
            hovertemplate="%{y} - %{x}: %{z}<extra></extra>",
        )
    )
    return _base_layout(fig, "Stakeholder Involvement by Role")


def task_completeness_bar(task_scores):
    """Bar chart of task completeness with traffic-light colouring.

    Args:
        task_scores: DataFrame with ``task_name`` and ``completeness`` columns.
    """
    def color_for(pct):
        if pct >= 80:
            return SUCCESS
        if pct >= 50:
            return WARNING
        return DANGER

    colors = [color_for(p) for p in task_scores["completeness"]]
    fig = go.Figure(
        go.Bar(
            x=task_scores["completeness"],
            y=task_scores["task_name"],
            orientation="h",
            marker_color=colors,
            text=[f"{p:.0f}%" for p in task_scores["completeness"]],
            textposition="auto",
        )
    )
    fig.update_layout(
        xaxis_title="Completeness (%)",
        yaxis_title="Task",
        xaxis_range=[0, 100],
    )
    return _base_layout(fig, "Task Completeness")
