"""Shared Streamlit UI helpers (path setup, branding, headers).

Pages call :func:`bootstrap` first. It makes sure the project root is on
``sys.path`` (so ``from utils...`` imports resolve when Streamlit runs a page
file directly) and injects the shared brand CSS.
"""

import os
import sys

import streamlit as st

PRIMARY = "#0B5B73"   # Teal
SECONDARY = "#1F3347"  # Navy


def ensure_project_root_on_path():
    """Add the project root to sys.path so ``utils`` is importable from pages."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if root not in sys.path:
        sys.path.insert(0, root)


def inject_brand_css():
    """Apply the teal/navy brand styling shared across pages."""
    st.markdown(
        f"""
        <style>
        h1, h2, h3 {{ color: {SECONDARY}; }}
        .stMetric {{
            background: #F4F8F9;
            border-left: 5px solid {PRIMARY};
            border-radius: 8px;
            padding: 12px 16px;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def page_header(title, description):
    """Render a consistent page title + one-line description."""
    st.title(title)
    st.caption(description)


def bootstrap(page_title, icon="🔬"):
    """Standard first call for every page: config + path + CSS.

    Call once at the very top of a page module.
    """
    st.set_page_config(
        page_title=f"{page_title} | AI ResearchOps Control Tower",
        page_icon=icon,
        layout="wide",
        initial_sidebar_state="expanded",
    )
    ensure_project_root_on_path()
    inject_brand_css()
