"""Unit tests for utils.scoring.

Run with:
    pytest tests/
"""

import pytest

from utils.scoring import (
    calculate_handover_readiness,
    calculate_risk_score,
    calculate_task_completeness,
    calculate_uncertainty_score,
    is_handover_ready,
    is_high_risk,
    task_completeness_color,
    uncertainty_zone,
)


# ---------------------------------------------------------------------------
# Uncertainty score
# ---------------------------------------------------------------------------
def test_uncertainty_score_average():
    assert calculate_uncertainty_score(5, 5, 5, 5, 5) == 5

def test_uncertainty_score_max():
    assert calculate_uncertainty_score(10, 10, 10, 10, 10) == 10

def test_uncertainty_score_mixed():
    # (7+6+8+7+6)/5 = 34/5 = 6.8
    assert calculate_uncertainty_score(7, 6, 8, 7, 6) == pytest.approx(6.8)

def test_uncertainty_zone_bands():
    assert uncertainty_zone(2) == "Low"
    assert uncertainty_zone(5) == "Medium"
    assert uncertainty_zone(9) == "High"


# ---------------------------------------------------------------------------
# Task completeness
# ---------------------------------------------------------------------------
def test_task_completeness_all_yes():
    task = {
        "clear_objective": "Yes",
        "has_owner": "Yes",
        "has_output": "Yes",
        "acceptance_criteria": "Yes",
        "dependencies": "Yes",
        "ai_metric": "Yes",
        "risk_level": "Yes",
        "timeline": "Yes",
        "stakeholder_impact": "Yes",
    }
    assert calculate_task_completeness(task) == 100

def test_task_completeness_none():
    assert calculate_task_completeness({}) == 0

def test_task_completeness_partial():
    # 3 of 9 fields = 33.33%
    task = {"clear_objective": "Yes", "has_owner": "Yes", "has_output": "Yes"}
    assert calculate_task_completeness(task) == pytest.approx(33.333, rel=1e-3)

def test_task_completeness_color_bands():
    assert task_completeness_color(90) == "Green"
    assert task_completeness_color(60) == "Yellow"
    assert task_completeness_color(20) == "Red"

def test_task_completeness_presence_based():
    # Content fields with real values count; "No"/"None" do not.
    task = {
        "clear_objective": "Yes",
        "has_owner": "Yes",
        "has_output": "No",        # not filled
        "acceptance_criteria": "Yes",
        "dependencies": "None",    # not filled
        "ai_metric": "F1 score",   # filled
        "risk_level": "High",      # filled
        "timeline": "2024-07-31",  # filled
        "stakeholder_impact": "Critical",  # filled
    }
    # 7 of 9 filled -> 77.78%
    assert calculate_task_completeness(task) == pytest.approx(77.778, rel=1e-3)


# ---------------------------------------------------------------------------
# Handover readiness
# ---------------------------------------------------------------------------
def test_handover_readiness_perfect():
    assert calculate_handover_readiness(10, 10, 10, 10, 10) == 100

def test_handover_readiness_mid():
    assert calculate_handover_readiness(5, 5, 5, 5, 5) == 50

def test_handover_readiness_threshold():
    assert is_handover_ready(calculate_handover_readiness(9, 9, 9, 9, 9)) is True
    assert is_handover_ready(calculate_handover_readiness(8, 8, 8, 8, 8)) is False


# ---------------------------------------------------------------------------
# Risk score
# ---------------------------------------------------------------------------
def test_risk_score_product():
    assert calculate_risk_score(4, 4) == 16

def test_risk_score_min_max():
    assert calculate_risk_score(1, 1) == 1
    assert calculate_risk_score(5, 5) == 25

def test_high_risk_flag():
    assert is_high_risk(16) is True
    assert is_high_risk(15) is False
