---
name: Experiment
about: Track an ML/AI experiment
title: "[EXPERIMENT] Experiment Name"
labels: experiment
---

## Hypothesis
<!-- What do we expect to happen and why? -->

## Baseline metric
<!-- Current value -->

## Target metric
<!-- Value we are aiming for -->

## Dataset
<!-- Source, size, splits -->

## Method
<!-- Model / approach / evaluation procedure -->

## Timeline
<!-- Start and expected end -->

## Success criteria
<!-- How we decide the experiment succeeded -->
