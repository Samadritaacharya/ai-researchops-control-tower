---
name: Risk
about: Log an AI/ML project risk
title: "[RISK] Risk Name"
labels: risk
---

## Category
<!-- Data / Model / Deployment / Organizational -->

## Impact (1-5)
<!-- 1 = negligible, 5 = severe -->

## Likelihood (1-5)
<!-- 1 = rare, 5 = almost certain -->

## Mitigation
<!-- Planned mitigation -->

## Owner
<!-- Who owns this risk -->

## Closure criteria
<!-- What needs to be true to close this risk -->
