---
name: Research Task
about: Define a research task with full readiness criteria
title: "[RESEARCH] Task Name"
labels: research-task
---

## Task objective
<!-- What is the goal of this task? -->

## Owner
<!-- Who is responsible? -->

## Acceptance criteria
- [ ] Criterion 1
- [ ] Criterion 2

## Dependencies
<!-- Other tasks or inputs this depends on -->

## Timeline
<!-- Target completion date -->

## Risk level
<!-- Low / Medium / High / Critical -->

## Stakeholder impact
<!-- Who is affected and how -->
