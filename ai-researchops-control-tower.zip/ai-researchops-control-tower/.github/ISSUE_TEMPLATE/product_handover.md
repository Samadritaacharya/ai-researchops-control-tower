---
name: Product Handover
about: Readiness review for moving a research prototype to product/engineering
title: "[HANDOVER] Project Name - Readiness Review"
labels: handover
---

## Checklist
- [ ] Evaluation complete
- [ ] Reproducibility documented
- [ ] All risks resolved or accepted
- [ ] Stakeholders aligned
- [ ] Full documentation ready

## Readiness score
<!-- 0-100 (see Handover Readiness scorecard) -->

## Blockers
<!-- What is preventing handover -->

## Sign-off from stakeholders
- [ ] Researcher
- [ ] Engineering
- [ ] Product
- [ ] Legal/Compliance
