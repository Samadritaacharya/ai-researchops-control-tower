# Project Charter Template

> Copy this template for each new research project.

## Project name
<!-- e.g. Proactive AI Coding Assistant -->

## Business case
Why does this research matter? What decision will the outcome inform?

## Research goal
The single question this project answers.

## Success criteria
- Measurable criterion 1
- Measurable criterion 2

## Key deliverables
- Deliverable 1
- Deliverable 2

## Stakeholders
| Role | Name | Involvement |
|------|------|-------------|
| Researcher | | R |
| Engineer | | A |
| Product Manager | | C |
| Legal/Compliance | | C |

## Timeline
| Milestone | Target date |
|-----------|-------------|
| Kickoff | |
| Mid-point review | |
| Handover decision | |

## Risks
See the AI/ML Risk Framework and the in-app Risk Register.

## Assumptions
- Assumption 1
- Assumption 2

## Constraints
- Budget / compute / time / data-access constraints
