# ResearchOps Process Map

The end-to-end flow this control tower supports.

```
Project intake
      |
      v
Uncertainty assessment  --> (score 1-10, assign Low/Medium/High zone)
      |
      v
Risk identification     --> (impact x likelihood, flag scores > 15)
      |
      v
Task planning           --> (nine-point completeness check)
      |
      v
Stakeholder alignment   --> (RACI matrix + communication cadence)
      |
      v
Experiment execution    --> (baseline -> target -> actual)
      |
      v
Evaluation              --> (success rate per track)
      |
      v
Handover decision       --> (readiness score > 80 = ready)
```

Each stage maps to a module in the app:

| Stage | Module |
|-------|--------|
| Project intake | Project Intake Wizard |
| Uncertainty assessment | Uncertainty & Scope Matrix |
| Risk identification | AI/ML Risk Register |
| Task planning | Task Completeness Analyzer |
| Stakeholder alignment | Stakeholder Map & RACI |
| Experiment execution & evaluation | Experiment Tracker |
| Handover decision | Status & Communication (Handover tab) |
