# Legal & Admin Checklist

Use before any research-to-product handover.

- [ ] **Data privacy review** completed (GDPR / regional equivalents).
- [ ] **IP ownership** clarified for data, models, and code.
- [ ] **Regulatory compliance** assessed for the target deployment region.
- [ ] **Data retention policy** defined and documented.
- [ ] **Model explainability** approach documented.
- [ ] **Documentation completeness** verified (charter, decisions, experiments).
- [ ] **Consent / telemetry** terms reviewed where developer data is collected.
- [ ] **Third-party licenses** for datasets and dependencies confirmed.
