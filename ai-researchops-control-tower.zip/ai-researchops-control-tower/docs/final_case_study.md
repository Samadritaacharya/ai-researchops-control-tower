# Case Study: Proactive AI Coding Assistant Research Program

## Problem statement
Developers lose time to friction inside the IDE — debugging dead ends,
unfamiliar code, repetitive refactors. Could a *proactive* AI assistant detect
that friction and offer useful, non-intrusive help at the right moment?

## Research goal
Design and manage an ML/AI research workflow to evaluate whether a proactive
assistant can identify developer friction and provide valuable in-IDE support.

## Tracks defined
1. **Intent Detection** — classify whether a developer is debugging,
   refactoring, documenting, or exploring.
2. **Suggestion Quality** — measure whether suggestions are useful, correct,
   and non-intrusive.
3. **Privacy & Data** — determine the minimum context required and what to
   exclude from model input.
4. **Product Handover** — decide when a prototype is mature enough to integrate.

## Case study results
- Intent classification reached 76% accuracy (v2), beating the 75% target.
- Suggestion ranking v2 hit 57% usefulness, beating its 55% target.
- Context minimization removed 34% of fields with no quality loss.
- The intrusiveness study failed (72% vs 80% target) and was deferred.

## Lessons learned
- Define ground truth and metrics *before* running experiments.
- Privacy minimization paid off twice: lower risk and a smaller model surface.
- Proactivity is the hardest dimension — usefulness without interruption needs
  dedicated UX research, not just modeling.

## Product handover decision
With three of four tracks meeting targets and the intrusiveness question open,
the program is **partially ready**: the intent and privacy work can hand over,
while suggestion proactivity stays in research. Readiness scoring keeps this
decision explicit rather than implicit.

## Future work
- Redesign and re-run the intrusiveness study.
- Add longitudinal model-drift monitoring.
- Expand the intent taxonomy with real-world developer feedback.
