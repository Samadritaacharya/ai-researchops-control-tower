# Decision Log

Record every significant decision. The Status & Communication page can export
new entries in this format.

| Decision ID | Date | Decision statement | Rationale | Impact | Owner | Status |
|-------------|------|--------------------|-----------|--------|-------|--------|
| D001 | 2024-03-12 | Use four-class developer intent taxonomy | Balances coverage and labeling effort | Shapes all intent experiments | Bob Smith | Approved |
| D002 | 2024-04-02 | Minimize collected IDE context fields | Reduces privacy risk | Lowers data risk score | Carol White | Approved |
| D003 | 2024-06-18 | Defer intrusiveness study to next quarter | Failed pilot, needs redesign | Delays suggestion-quality track | Alice Chen | Approved |
