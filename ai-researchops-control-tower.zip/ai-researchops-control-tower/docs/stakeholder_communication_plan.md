# Stakeholder Communication Plan

| Stakeholder role | Communication frequency | Information needs | Escalation path | Meeting cadence |
|------------------|------------------------|-------------------|-----------------|-----------------|
| Researcher | Daily | Task status, experiment results | Tech lead | Daily stand-up |
| Engineer | Daily | Interfaces, data contracts, handover readiness | Tech lead | Daily stand-up |
| Product Manager | Weekly | Progress vs goal, risks, timelines | Program lead | Weekly sync |
| Legal/Compliance | Bi-weekly | Data handling, privacy, IP | Program lead | Bi-weekly review |
| Academic Partner | Monthly | Methodology, findings | Research lead | Monthly check-in |
| Executive Sponsor | Monthly | Outcomes, budget, go/no-go | Program lead | Monthly steering |
