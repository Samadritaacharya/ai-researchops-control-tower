# AI/ML Risk Framework

A taxonomy for identifying and managing risk in AI/ML research projects.
Risk score = impact (1-5) x likelihood (1-5). Scores above 15 are high severity.

## 1. Data risks
- **Quality**: noisy, mislabeled, or incomplete data.
- **Bias**: training data not representative of real usage.
- **Availability**: data access blocked or delayed.
- **Privacy/compliance**: GDPR and similar requirements (especially relevant for IDE telemetry).

## 2. Model risks
- **Drift**: performance degrades as the environment changes.
- **Reproducibility**: results cannot be reliably re-created.
- **Generalization**: model fails outside the training distribution.
- **Evaluation ambiguity**: no agreed ground truth or metric.

## 3. Deployment risks
- **Latency**: real-time constraints not met.
- **Cost**: inference too expensive at scale.
- **Monitoring**: no observability after release.
- **Fairness & explainability**: outputs hard to justify to users.

## 4. Organizational risks
- **Stakeholder alignment**: conflicting goals or priorities.
- **Documentation**: insufficient for handover.
- **Knowledge transfer**: research context lost between teams.

## Mitigation strategies
- Define metrics and ground truth before experimentation.
- Maintain a decision log and reproducible pipelines.
- Run privacy review early; minimize collected context.
- Keep the risk register live; review high-severity risks weekly.

## Monitoring approach
- Quarterly model performance checks.
- Continuous tracking of open vs mitigated vs closed risks.
- Re-score uncertainty at each milestone.
