# Screenshots

Add screenshots of each module here and reference them in the README, e.g.

```
![Dashboard](docs/screenshots/dashboard.png)
```
