"""Module 4 - AI/ML Risk Register.

Manage an AI/ML risk taxonomy: view, add, and remove risks, see the heatmap,
and flag high-severity risks (score > 15).
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_risks
from utils.scoring import calculate_risk_score, is_high_risk
from utils.visualization import risk_heatmap

bootstrap("Risk Register")
page_header(
    "⚠️ AI/ML Risk Register",
    "Track data, model, deployment, and organizational risks.",
)

CATEGORIES = ["Data Risks", "Model Risks", "Deployment Risks", "Organizational Risks"]
STATUSES = ["Open", "Mitigated", "Closed"]

# Load base risks once into session so add/delete persists during the session.
if "risks_df" not in st.session_state:
    try:
        st.session_state.risks_df = load_risks()
    except Exception as exc:  # noqa: BLE001
        st.error(f"Could not load risks: {exc}")
        st.session_state.risks_df = pd.DataFrame()

risks = st.session_state.risks_df.copy()
if not risks.empty:
    risks["risk_score"] = risks.apply(
        lambda r: calculate_risk_score(r["impact"], r["likelihood"]), axis=1
    )
    risks["high_risk"] = risks["risk_score"].apply(is_high_risk)

# ---------------------------------------------------------------------------
# KPI row
# ---------------------------------------------------------------------------
c1, c2, c3 = st.columns(3)
c1.metric("Total risks", len(risks))
c2.metric("Open risks", int((risks["status"].str.lower() == "open").sum()) if not risks.empty else 0)
c3.metric("High severity (>15)", int(risks["high_risk"].sum()) if not risks.empty else 0)

# ---------------------------------------------------------------------------
# Heatmap
# ---------------------------------------------------------------------------
if not risks.empty:
    st.subheader("Risk heatmap")
    st.plotly_chart(risk_heatmap(risks), use_container_width=True)

    high = risks[risks["high_risk"]]
    if not high.empty:
        st.error(
            "High-severity risks needing immediate mitigation: "
            + ", ".join(high["title"].tolist())
        )

# ---------------------------------------------------------------------------
# Register table
# ---------------------------------------------------------------------------
st.subheader("Risk register")
if not risks.empty:
    st.dataframe(
        risks[
            [
                "risk_id",
                "project_id",
                "title",
                "category",
                "impact",
                "likelihood",
                "risk_score",
                "status",
                "owner",
            ]
        ],
        use_container_width=True,
        hide_index=True,
    )

# ---------------------------------------------------------------------------
# Add a new risk
# ---------------------------------------------------------------------------
st.subheader("Add a risk")
with st.form("add_risk", clear_on_submit=True):
    col1, col2 = st.columns(2)
    with col1:
        risk_id = st.text_input("Risk ID", value=f"R{len(risks) + 1:03d}")
        project_id = st.text_input("Project ID", value="P001")
        title = st.text_input("Title")
        category = st.selectbox("Category", CATEGORIES)
    with col2:
        impact = st.slider("Impact", 1, 5, 3)
        likelihood = st.slider("Likelihood", 1, 5, 3)
        owner = st.text_input("Owner")
        status = st.selectbox("Status", STATUSES)
    description = st.text_area("Description")
    mitigation = st.text_area("Mitigation plan")
    add = st.form_submit_button("Add risk")

if add:
    if not title.strip():
        st.error("Please provide a risk title.")
    else:
        new_row = {
            "risk_id": risk_id,
            "project_id": project_id,
            "title": title,
            "category": category,
            "description": description,
            "impact": impact,
            "likelihood": likelihood,
            "mitigation": mitigation,
            "owner": owner,
            "status": status,
        }
        st.session_state.risks_df = pd.concat(
            [st.session_state.risks_df, pd.DataFrame([new_row])],
            ignore_index=True,
        )
        score = calculate_risk_score(impact, likelihood)
        flag = " (HIGH SEVERITY)" if is_high_risk(score) else ""
        st.success(f"Added '{title}' with risk score {score}{flag}.")
        st.rerun()

# ---------------------------------------------------------------------------
# Delete a risk
# ---------------------------------------------------------------------------
if not st.session_state.risks_df.empty:
    st.subheader("Remove a risk")
    to_delete = st.selectbox(
        "Select a risk to remove",
        st.session_state.risks_df["risk_id"].tolist(),
    )
    if st.button("Delete selected risk"):
        st.session_state.risks_df = st.session_state.risks_df[
            st.session_state.risks_df["risk_id"] != to_delete
        ].reset_index(drop=True)
        st.success(f"Removed {to_delete}.")
        st.rerun()
