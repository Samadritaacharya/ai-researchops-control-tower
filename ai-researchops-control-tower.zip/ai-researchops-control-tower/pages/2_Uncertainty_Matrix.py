"""Module 3 - Uncertainty & Scope Matrix.

Plot every project on a goal-volatility vs data/model-uncertainty matrix,
compute the uncertainty score, and surface recommendations by risk zone.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_project_data
from utils.scoring import calculate_uncertainty_score, uncertainty_zone
from utils.visualization import uncertainty_bubble_matrix

bootstrap("Uncertainty Matrix")
page_header(
    "📊 Uncertainty & Scope Matrix",
    "Score and visualise how uncertain each research project is.",
)

RECOMMENDATIONS = {
    "Low": "Low uncertainty — proceed with a standard delivery plan and light "
    "checkpoints.",
    "Medium": "Medium uncertainty — run short experiments, set decision gates, "
    "and revisit scope every sprint.",
    "High": "High uncertainty — treat as discovery research. Time-box spikes, "
    "align stakeholders early, and avoid hard delivery commitments.",
}

try:
    projects = load_project_data()
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not load projects: {exc}")
    st.stop()

# ---------------------------------------------------------------------------
# Matrix plot
# ---------------------------------------------------------------------------
st.subheader("Project uncertainty matrix")
st.caption("Bubble size = stakeholder dependency. Colour = overall uncertainty score.")
st.plotly_chart(uncertainty_bubble_matrix(projects), use_container_width=True)

# ---------------------------------------------------------------------------
# Per-project scores + zone
# ---------------------------------------------------------------------------
scored = projects.copy()
scored["uncertainty_score"] = scored.apply(
    lambda r: round(
        calculate_uncertainty_score(
            r["goal_volatility"],
            r["data_uncertainty"],
            r["model_uncertainty"],
            r["stakeholder_dependency"],
            r["legal_complexity"],
        ),
        2,
    ),
    axis=1,
)
scored["zone"] = scored["uncertainty_score"].apply(uncertainty_zone)

st.subheader("Scores by project")
st.dataframe(
    scored[["project_id", "project_name", "uncertainty_score", "zone"]],
    use_container_width=True,
    hide_index=True,
)

# ---------------------------------------------------------------------------
# Manual / what-if scoring
# ---------------------------------------------------------------------------
st.subheader("What-if scoring")
st.caption("Adjust the sliders to score a hypothetical or revised project.")
col1, col2, col3, col4, col5 = st.columns(5)
gv = col1.slider("Goal volatility", 1, 10, 5, key="gv")
du = col2.slider("Data uncertainty", 1, 10, 5, key="du")
mu = col3.slider("Model uncertainty", 1, 10, 5, key="mu")
sd = col4.slider("Stakeholder dep.", 1, 10, 5, key="sd")
lc = col5.slider("Legal complexity", 1, 10, 5, key="lc")

manual_score = calculate_uncertainty_score(gv, du, mu, sd, lc)
zone = uncertainty_zone(manual_score)
st.metric("Uncertainty score", f"{manual_score:.1f} / 10", help=f"Zone: {zone}")

if zone == "High":
    st.error(RECOMMENDATIONS["High"])
elif zone == "Medium":
    st.warning(RECOMMENDATIONS["Medium"])
else:
    st.success(RECOMMENDATIONS["Low"])
