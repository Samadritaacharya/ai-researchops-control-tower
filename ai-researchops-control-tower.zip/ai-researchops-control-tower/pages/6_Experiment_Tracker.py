"""Module 7 - Experiment Tracker.

Track ML/AI experiments per research track, view baseline vs actual metric
trends, and compute the success rate per track.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_experiments, metric_to_float
from utils.visualization import experiment_trend

bootstrap("Experiment Tracker")
page_header(
    "🧪 Experiment Tracker",
    "Hypotheses, baselines, targets, and outcomes across research tracks.",
)

STATUS_BADGE = {
    "Completed": "✅ Completed",
    "Running": "🔵 Running",
    "Failed": "🔴 Failed",
}

try:
    experiments = load_experiments()
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not load experiments: {exc}")
    st.stop()

experiments = experiments.copy()


def hit_target(row):
    """An experiment 'succeeds' when actual >= target (both parseable)."""
    actual = metric_to_float(row["actual_metric"])
    target = metric_to_float(row["target_metric"])
    if actual is None or target is None:
        return None
    return actual >= target


experiments["target_met"] = experiments.apply(hit_target, axis=1)

# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------
col1, col2 = st.columns(2)
tracks = ["All"] + sorted(experiments["track"].unique().tolist())
projects = ["All"] + sorted(experiments["project_id"].unique().tolist())
track_filter = col1.selectbox("Track", tracks)
project_filter = col2.selectbox("Project", projects)

view = experiments
if track_filter != "All":
    view = view[view["track"] == track_filter]
if project_filter != "All":
    view = view[view["project_id"] == project_filter]

# ---------------------------------------------------------------------------
# KPIs
# ---------------------------------------------------------------------------
completed = view[view["status"] == "Completed"]
met = int((completed["target_met"] == True).sum())  # noqa: E712
success_rate = (met / len(completed) * 100) if len(completed) else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("Experiments", len(view))
c2.metric("Running", int((view["status"] == "Running").sum()))
c3.metric("Completed", len(completed))
c4.metric("Success rate", f"{success_rate:.0f}%", help="Completed experiments meeting their target")

# ---------------------------------------------------------------------------
# Trend chart
# ---------------------------------------------------------------------------
if not view.empty:
    st.subheader("Baseline vs actual")
    st.plotly_chart(experiment_trend(view), use_container_width=True)

# ---------------------------------------------------------------------------
# Table
# ---------------------------------------------------------------------------
st.subheader("Experiments")
table = view.copy()
table["status_badge"] = table["status"].map(lambda s: STATUS_BADGE.get(s, s))
table["target_met"] = table["target_met"].map(
    {True: "Yes", False: "No"}
).fillna("—")
st.dataframe(
    table[
        ["experiment_id", "project_id", "track", "experiment_name",
         "baseline_metric", "target_metric", "actual_metric",
         "target_met", "status_badge"]
    ],
    use_container_width=True,
    hide_index=True,
)

# ---------------------------------------------------------------------------
# Success rate by track
# ---------------------------------------------------------------------------
st.subheader("Success rate by track")
rows = []
for track, group in experiments.groupby("track"):
    done = group[group["status"] == "Completed"]
    track_met = int((done["target_met"] == True).sum())  # noqa: E712
    rate = (track_met / len(done) * 100) if len(done) else 0
    rows.append(
        {
            "track": track,
            "completed": len(done),
            "met_target": track_met,
            "success_rate_%": round(rate),
        }
    )
st.dataframe(rows, use_container_width=True, hide_index=True)
