"""Module 8 - Status & Communication Generator (+ Module 9 Handover Scorecard).

Generate weekly status reports, keep a decision log, and score product-handover
readiness per project.
"""

import os
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_project_data, load_risks, load_tasks
from utils.scoring import (
    calculate_handover_readiness,
    calculate_risk_score,
    calculate_task_completeness,
    is_handover_ready,
    is_high_risk,
)

bootstrap("Status & Communication")
page_header(
    "📝 Status & Communication",
    "Weekly reports, decision log, and product-handover readiness.",
)

# Decision log lives in session state.
if "decision_log" not in st.session_state:
    st.session_state.decision_log = []

try:
    projects = load_project_data()
    risks = load_risks()
    tasks = load_tasks()
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not load data: {exc}")
    st.stop()

risks = risks.copy()
risks["risk_score"] = risks.apply(
    lambda r: calculate_risk_score(r["impact"], r["likelihood"]), axis=1
)
tasks = tasks.copy()
tasks["completeness"] = tasks.apply(
    lambda r: calculate_task_completeness(r.to_dict()), axis=1
)

tab_report, tab_decisions, tab_handover = st.tabs(
    ["Weekly status report", "Decision log", "Handover readiness"]
)

# ===========================================================================
# Tab 1: Weekly status report generator
# ===========================================================================
with tab_report:
    st.subheader("Generate a weekly status report")
    project_id = st.selectbox(
        "Project", projects["project_id"].tolist(), key="report_project"
    )
    report_date = st.date_input("Report date", value=date.today())

    proj = projects[projects["project_id"] == project_id].iloc[0]
    p_tasks = tasks[tasks["project_id"] == project_id]
    p_risks = risks[risks["project_id"] == project_id]

    completed_tasks = p_tasks[p_tasks["status"] == "Completed"]
    open_high_risks = p_risks[
        (p_risks["status"].str.lower() == "open")
        & (p_risks["risk_score"].apply(is_high_risk))
    ]
    avg_completion = p_tasks["completeness"].mean() if len(p_tasks) else 0

    report = f"""# Weekly Status Report — {proj['project_name']}

**Date:** {report_date.isoformat()}
**Project:** {project_id} — {proj['project_name']}
**Researcher:** {proj['primary_researcher']}
**Status:** {proj['status']}

## Summary
- Completed tasks: {len(completed_tasks)} of {len(p_tasks)}
- Average task completeness: {avg_completion:.0f}%

## Progress metrics
- Tasks in progress: {int((p_tasks['status'] == 'In Progress').sum())}
- Tasks not started: {int((p_tasks['status'] == 'Not Started').sum())}
- Open risks: {int((p_risks['status'].str.lower() == 'open').sum())}

## Blockers & risks
{(chr(10).join('- ' + t + ' (HIGH)' for t in open_high_risks['title'].tolist())) or '- No high-severity open risks.'}

## Stakeholder updates
- Next steps: progress in-flight tasks and close out high-severity risks.
"""

    st.text_area("Report preview (editable)", value=report, height=380, key="report_text")
    st.download_button(
        "⬇️ Download report (Markdown)",
        data=st.session_state.get("report_text", report),
        file_name=f"{project_id}_status_{report_date.isoformat()}.md",
        mime="text/markdown",
    )

# ===========================================================================
# Tab 2: Decision log
# ===========================================================================
with tab_decisions:
    st.subheader("Record a decision")
    with st.form("decision_form", clear_on_submit=True):
        statement = st.text_input("Decision statement")
        rationale = st.text_area("Rationale")
        col1, col2 = st.columns(2)
        owner = col1.text_input("Owner")
        status = col2.selectbox("Status", ["Proposed", "Approved", "Rejected", "Superseded"])
        impact = st.text_area("Impact")
        save = st.form_submit_button("Add to decision log")

    if save and statement.strip():
        st.session_state.decision_log.append(
            {
                "id": f"D{len(st.session_state.decision_log) + 1:03d}",
                "date": date.today().isoformat(),
                "decision": statement,
                "rationale": rationale,
                "impact": impact,
                "owner": owner,
                "status": status,
            }
        )
        st.success("Decision recorded.")

    if st.session_state.decision_log:
        st.dataframe(
            st.session_state.decision_log,
            use_container_width=True,
            hide_index=True,
        )
        # Export the log as markdown.
        lines = ["# Decision Log", ""]
        for d in st.session_state.decision_log:
            lines.append(
                f"- **{d['id']}** ({d['date']}, {d['status']}): {d['decision']} "
                f"— _{d['rationale']}_ [owner: {d['owner']}]"
            )
        st.download_button(
            "⬇️ Download decision log",
            data="\n".join(lines),
            file_name="decision_log.md",
            mime="text/markdown",
        )
    else:
        st.info("No decisions recorded yet.")

# ===========================================================================
# Tab 3: Product handover readiness scorecard (Module 9)
# ===========================================================================
with tab_handover:
    st.subheader("Product handover readiness scorecard")
    hp = st.selectbox(
        "Project", projects["project_id"].tolist(), key="handover_project"
    )
    st.caption("Score each dimension 1-10.")

    col1, col2 = st.columns(2)
    with col1:
        evaluation_quality = st.slider("Evaluation quality", 1, 10, 6)
        reproducibility = st.slider("Reproducibility", 1, 10, 6)
        stakeholder_alignment = st.slider("Stakeholder alignment", 1, 10, 6)
    with col2:
        risk_closure = st.slider("Risk closure", 1, 10, 6)
        documentation_maturity = st.slider("Documentation maturity", 1, 10, 6)

    readiness = calculate_handover_readiness(
        evaluation_quality,
        reproducibility,
        stakeholder_alignment,
        risk_closure,
        documentation_maturity,
    )

    st.metric("Readiness score", f"{readiness:.0f} / 100")

    if is_handover_ready(readiness):
        st.success("✅ Ready for handover (score > 80). Proceed to engineering integration.")
    else:
        st.warning(f"Not yet ready (score {readiness:.0f}). Raise the lowest-scoring dimensions first.")

    # Checklist
    st.markdown("#### Handover checklist")
    checks = {
        "Evaluation complete": evaluation_quality >= 8,
        "Reproducibility documented": reproducibility >= 8,
        "All risks resolved": risk_closure >= 8,
        "Stakeholders aligned": stakeholder_alignment >= 8,
        "Full documentation ready": documentation_maturity >= 8,
    }
    for label, ok in checks.items():
        st.write(f"{'✅' if ok else '⬜'} {label}")

    # Recommendations
    components = {
        "Evaluation quality": evaluation_quality,
        "Reproducibility": reproducibility,
        "Stakeholder alignment": stakeholder_alignment,
        "Risk closure": risk_closure,
        "Documentation maturity": documentation_maturity,
    }
    weakest = min(components, key=components.get)
    st.info(f"Recommended next action: improve **{weakest}** (currently {components[weakest]}/10).")
