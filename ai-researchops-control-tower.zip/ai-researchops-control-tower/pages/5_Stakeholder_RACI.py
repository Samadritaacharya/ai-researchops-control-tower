"""Module 6 - Stakeholder Map & RACI Matrix.

View stakeholders per project, the RACI matrix, an involvement heatmap, and
communication-frequency recommendations.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_stakeholders
from utils.visualization import stakeholder_involvement_heatmap

bootstrap("Stakeholder RACI")
page_header(
    "👥 Stakeholder Map & RACI Matrix",
    "Who is Responsible, Accountable, Consulted, and Informed.",
)

# Recommended communication cadence by role.
COMM_FREQUENCY = {
    "Researcher": "Daily stand-up",
    "Engineer": "Daily stand-up",
    "Product Manager": "Weekly sync",
    "Legal/Compliance": "Bi-weekly review",
    "Academic Partner": "Monthly check-in",
    "Executive Sponsor": "Monthly steering",
}

try:
    stakeholders = load_stakeholders()
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not load stakeholders: {exc}")
    st.stop()

# ---------------------------------------------------------------------------
# Project filter
# ---------------------------------------------------------------------------
projects = ["All"] + sorted(stakeholders["project_id"].unique().tolist())
selected_project = st.selectbox("Filter by project", projects)

view = stakeholders if selected_project == "All" else stakeholders[
    stakeholders["project_id"] == selected_project
]

# ---------------------------------------------------------------------------
# RACI matrix
# ---------------------------------------------------------------------------
st.subheader("RACI matrix")


def raci_label(row):
    labels = []
    if row["responsible"] == "Yes":
        labels.append("R")
    if row["accountable"] == "Yes":
        labels.append("A")
    if row["consulted"] == "Yes":
        labels.append("C")
    if row["informed"] == "Yes":
        labels.append("I")
    return ", ".join(labels) if labels else "-"


display = view.copy()
display["RACI"] = display.apply(raci_label, axis=1)
st.dataframe(
    display[["project_id", "stakeholder_name", "role", "RACI"]],
    use_container_width=True,
    hide_index=True,
)

# ---------------------------------------------------------------------------
# Involvement heatmap
# ---------------------------------------------------------------------------
st.subheader("Involvement heatmap")
st.plotly_chart(
    stakeholder_involvement_heatmap(view), use_container_width=True
)

# ---------------------------------------------------------------------------
# Communication recommendations
# ---------------------------------------------------------------------------
st.subheader("Communication frequency recommendations")
roles_present = sorted(view["role"].unique().tolist())
rec_rows = [
    {"role": role, "recommended_cadence": COMM_FREQUENCY.get(role, "As needed")}
    for role in roles_present
]
st.dataframe(rec_rows, use_container_width=True, hide_index=True)

# ---------------------------------------------------------------------------
# Add a stakeholder (session only)
# ---------------------------------------------------------------------------
st.subheader("Add a stakeholder")
with st.form("add_stakeholder", clear_on_submit=True):
    col1, col2 = st.columns(2)
    with col1:
        new_project = st.text_input("Project ID", value="P001")
        name = st.text_input("Name")
        role = st.selectbox("Role", list(COMM_FREQUENCY.keys()))
    with col2:
        responsible = st.checkbox("Responsible")
        accountable = st.checkbox("Accountable")
        consulted = st.checkbox("Consulted")
        informed = st.checkbox("Informed")
    add = st.form_submit_button("Add")

if add and name.strip():
    st.success(
        f"{name} ({role}) added to {new_project} — "
        f"{raci_label({'responsible': 'Yes' if responsible else 'No', 'accountable': 'Yes' if accountable else 'No', 'consulted': 'Yes' if consulted else 'No', 'informed': 'Yes' if informed else 'No'})}. "
        "(Session preview only — edit the CSV to persist.)"
    )
elif add:
    st.error("Please provide a name.")
