"""Module 5 - Task Completeness Analyzer.

Score each task across nine readiness dimensions, colour-code by completeness,
and show a project-level aggregate.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_tasks
from utils.scoring import (
    TASK_REQUIRED_FIELDS,
    calculate_task_completeness,
    task_completeness_color,
)
from utils.visualization import task_completeness_bar

bootstrap("Task Completeness")
page_header(
    "✅ Task Completeness Analyzer",
    "How ready is each task? Nine checks, one score.",
)

COLOR_EMOJI = {"Green": "🟢", "Yellow": "🟡", "Red": "🔴"}

try:
    tasks = load_tasks()
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not load tasks: {exc}")
    st.stop()

# ---------------------------------------------------------------------------
# Score every task
# ---------------------------------------------------------------------------
tasks = tasks.copy()
tasks["completeness"] = tasks.apply(
    lambda r: calculate_task_completeness(r.to_dict()), axis=1
)
tasks["health"] = tasks["completeness"].apply(task_completeness_color)
tasks["health_badge"] = tasks["health"].map(lambda h: f"{COLOR_EMOJI[h]} {h}")

# ---------------------------------------------------------------------------
# KPIs
# ---------------------------------------------------------------------------
c1, c2, c3, c4 = st.columns(4)
c1.metric("Tasks", len(tasks))
c2.metric("Avg completeness", f"{tasks['completeness'].mean():.0f}%")
c3.metric("Green (>=80%)", int((tasks["health"] == "Green").sum()))
c4.metric("Red (<50%)", int((tasks["health"] == "Red").sum()))

# ---------------------------------------------------------------------------
# Bar chart
# ---------------------------------------------------------------------------
st.subheader("Completeness by task")
st.plotly_chart(task_completeness_bar(tasks), use_container_width=True)

# ---------------------------------------------------------------------------
# Table
# ---------------------------------------------------------------------------
st.subheader("Task backlog")
st.dataframe(
    tasks[
        ["task_id", "project_id", "task_name", "owner", "status",
         "completeness", "health_badge"]
    ].rename(columns={"completeness": "completeness_%"}),
    use_container_width=True,
    hide_index=True,
)

# ---------------------------------------------------------------------------
# Project-level aggregate
# ---------------------------------------------------------------------------
st.subheader("Completeness by project")
agg = (
    tasks.groupby("project_id")["completeness"].mean().round(0).reset_index()
)
agg.columns = ["project_id", "avg_completeness_%"]
st.dataframe(agg, use_container_width=True, hide_index=True)

# ---------------------------------------------------------------------------
# Inspect / what-if a single task
# ---------------------------------------------------------------------------
st.subheader("Inspect a task")
selected = st.selectbox("Select a task", tasks["task_id"].tolist())
row = tasks[tasks["task_id"] == selected].iloc[0]

with st.expander(f"Checklist for {selected} — {row['task_name']}", expanded=True):
    for field in TASK_REQUIRED_FIELDS:
        present = str(row.get(field)) == "Yes"
        mark = "✅" if present else "❌"
        st.write(f"{mark} {field.replace('_', ' ').title()}")
    st.info(
        f"Completeness: {row['completeness']:.0f}% "
        f"({COLOR_EMOJI[row['health']]} {row['health']})"
    )
