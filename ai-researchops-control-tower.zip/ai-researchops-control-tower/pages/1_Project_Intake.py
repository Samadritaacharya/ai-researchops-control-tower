"""Module 2 - Research Project Intake Wizard.

Create new research projects, generate a charter on submission, and review
existing projects with status badges.
"""

import os
import sys

# Make sure the project root is importable when Streamlit runs this file.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from utils.ui import bootstrap, page_header
from utils.data_loader import load_project_data
from utils.scoring import calculate_uncertainty_score, uncertainty_zone

bootstrap("Project Intake")
page_header(
    "📥 Research Project Intake Wizard",
    "Register a new research project and generate its charter.",
)

# Session state holds projects created during this session (in addition to CSV).
if "new_projects" not in st.session_state:
    st.session_state.new_projects = []

STATUS_BADGE = {
    "Active": "🟢 Active",
    "Completed": "✅ Completed",
    "Draft": "🟠 Draft",
    "On Hold": "⚪ On Hold",
}


# ---------------------------------------------------------------------------
# Intake form
# ---------------------------------------------------------------------------
st.subheader("Create a new project")

with st.form("intake_form", clear_on_submit=False):
    col1, col2 = st.columns(2)
    with col1:
        project_name = st.text_input("Project name", placeholder="e.g. Proactive AI Coding Assistant")
        research_goal = st.text_area("Research goal", placeholder="What question are we trying to answer?")
        primary_researcher = st.text_input("Primary researcher", placeholder="e.g. Alice Chen")
        status = st.selectbox("Status", ["Draft", "Active", "On Hold", "Completed"])
    with col2:
        expected_duration = st.text_input("Expected duration", placeholder="e.g. 6 months")
        key_stakeholders = st.text_input("Key stakeholders", placeholder="comma separated")
        goal_volatility = st.slider("Goal volatility", 1, 10, 5)
        data_uncertainty = st.slider("Data uncertainty", 1, 10, 5)
        model_uncertainty = st.slider("Model uncertainty", 1, 10, 5)
        stakeholder_dependency = st.slider("Stakeholder dependency", 1, 10, 5)
        legal_complexity = st.slider("Legal / privacy complexity", 1, 10, 5)

    submitted = st.form_submit_button("Create project & generate charter")

if submitted:
    if not project_name.strip():
        st.error("Please provide a project name.")
    else:
        score = calculate_uncertainty_score(
            goal_volatility,
            data_uncertainty,
            model_uncertainty,
            stakeholder_dependency,
            legal_complexity,
        )
        record = {
            "project_name": project_name,
            "research_goal": research_goal,
            "primary_researcher": primary_researcher,
            "status": status,
            "expected_duration": expected_duration,
            "key_stakeholders": key_stakeholders,
            "uncertainty_score": score,
            "uncertainty_zone": uncertainty_zone(score),
        }
        st.session_state.new_projects.append(record)
        st.success(f"Project '{project_name}' created. Uncertainty score: {score:.1f} ({uncertainty_zone(score)}).")

        # Auto-generated charter
        charter = f"""# Project Charter: {project_name}

**Primary researcher:** {primary_researcher or 'TBD'}
**Status:** {status}
**Expected duration:** {expected_duration or 'TBD'}
**Key stakeholders:** {key_stakeholders or 'TBD'}

## Research goal
{research_goal or 'TBD'}

## Initial uncertainty assessment
- Goal volatility: {goal_volatility}/10
- Data uncertainty: {data_uncertainty}/10
- Model uncertainty: {model_uncertainty}/10
- Stakeholder dependency: {stakeholder_dependency}/10
- Legal / privacy complexity: {legal_complexity}/10
- **Overall uncertainty score: {score:.1f}/10 ({uncertainty_zone(score)})**

## Next steps
1. Run a full risk identification pass (see Risk Register).
2. Break the goal into tasks (see Task Completeness).
3. Confirm the RACI matrix (see Stakeholder RACI).
"""
        st.download_button(
            "⬇️ Download charter (Markdown)",
            data=charter,
            file_name=f"{project_name.lower().replace(' ', '_')}_charter.md",
            mime="text/markdown",
        )
        with st.expander("Preview generated charter"):
            st.markdown(charter)


# ---------------------------------------------------------------------------
# Projects created this session
# ---------------------------------------------------------------------------
if st.session_state.new_projects:
    st.subheader("Projects created this session")
    st.dataframe(st.session_state.new_projects, use_container_width=True)


# ---------------------------------------------------------------------------
# Existing projects from sample data
# ---------------------------------------------------------------------------
st.subheader("Existing projects")
try:
    projects = load_project_data()
    display = projects.copy()
    display["status_badge"] = display["status"].map(
        lambda s: STATUS_BADGE.get(s, s)
    )
    display["uncertainty_score"] = display.apply(
        lambda r: round(
            calculate_uncertainty_score(
                r["goal_volatility"],
                r["data_uncertainty"],
                r["model_uncertainty"],
                r["stakeholder_dependency"],
                r["legal_complexity"],
            ),
            1,
        ),
        axis=1,
    )
    st.dataframe(
        display[
            [
                "project_id",
                "project_name",
                "primary_researcher",
                "status_badge",
                "uncertainty_score",
                "start_date",
                "expected_end_date",
            ]
        ],
        use_container_width=True,
        hide_index=True,
    )
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not load existing projects: {exc}")
